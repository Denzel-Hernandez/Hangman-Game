﻿using System;
using System.Collections.Generic;
using System.Linq;

class Hangman
{
    static Dictionary<string, List<string>> wordCategories = new Dictionary<string, List<string>>()
    {
        { "Easy", new List<string> { "apple", "ball", "cat", "dog", "egg", "fish", "goat", "hat", "ice", "jam" } },
        { "Medium", new List<string> { "jungle", "kingdom", "lemonade", "mountain", "notebook", "octopus", "penguin", "quartz", "rainbow", "sunflower" } },
        { "Hard", new List<string> { "xylophone", "juxtapose", "quizzical", "zodiac", "mnemonic", "quarantine", "rhythm", "synergy", "vortex", "whimsical" } }
    };

    static int totalScore = 0;
    static int highScore = 0;

    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to Hangman!");

        bool playAgain = true;
        while (playAgain)
        {
            PlayGame();
            Console.Write("\nDo you want to play another round? (y/n): ");
            string input = Console.ReadLine()?.Trim().ToLower();
            playAgain = input == "y";

            if (totalScore > highScore)
            {
                highScore = totalScore;
            }
        }

        Console.WriteLine($"\nThank you for playing! Your highest score was: {highScore}");
        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();
    }

    static void PlayGame()
    {
        string difficulty = ChooseDifficulty();
        string wordToGuess = GetRandomWord(difficulty);
        string hint = GetHint(wordToGuess);
        char[] guessedWord = new string('_', wordToGuess.Length).ToCharArray();
        int attempts = 6;
        bool won = false;
        HashSet<char> guessedLetters = new HashSet<char>();
        bool hintUsed = false;

        while (attempts > 0 && !won)
        {
            Console.Clear();
            DisplayHangman(attempts);
            Console.WriteLine($"\nCategory: {difficulty}");
            Console.WriteLine($"Word: {new string(guessedWord)}");
            Console.WriteLine($"Attempts left: {attempts}");
            Console.WriteLine($"Guessed letters: {string.Join(", ", guessedLetters)}");

            Console.Write("\nGuess a letter or type 'hint' to reveal a letter (costs 1 attempt): ");
            string input = Console.ReadLine()?.Trim().ToLower();

            if (input == "hint")
            {
                if (!hintUsed)
                {
                    RevealLetter(wordToGuess, guessedWord, guessedLetters);
                    attempts--;
                    hintUsed = true;
                }
                else
                {
                    Console.WriteLine("Hint has already been used this round.");
                    Console.WriteLine("Press any key to continue.");
                    Console.ReadKey();
                }
                continue;
            }

            if (string.IsNullOrWhiteSpace(input) || input.Length != 1)
            {
                Console.WriteLine("Invalid input. Please enter a single letter.");
                Console.WriteLine("Press any key to continue.");
                Console.ReadKey();
                continue;
            }

            char guessedLetter = input[0];

            if (!char.IsLetter(guessedLetter))
            {
                Console.WriteLine("Invalid input. Please enter a valid letter (A-Z).");
                Console.WriteLine("Press any key to continue.");
                Console.ReadKey();
                continue;
            }

            guessedLetter = char.ToLower(guessedLetter);

            if (guessedLetters.Contains(guessedLetter))
            {
                Console.WriteLine($"You've already guessed '{guessedLetter}'. Try a different letter.");
                Console.WriteLine("Press any key to continue.");
                Console.ReadKey();
                continue;
            }

            guessedLetters.Add(guessedLetter);

            if (wordToGuess.Contains(guessedLetter))
            {
                for (int i = 0; i < wordToGuess.Length; i++)
                {
                    if (wordToGuess[i] == guessedLetter)
                    {
                        guessedWord[i] = guessedLetter;
                    }
                }
                Console.WriteLine($"Good guess! The letter '{guessedLetter}' is in the word.");
            }
            else
            {
                attempts--;
                Console.WriteLine($"Wrong guess! The letter '{guessedLetter}' is not in the word.");
            }

            if (new string(guessedWord) == wordToGuess)
            {
                won = true;
                totalScore += attempts * 10;
            }

            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }

        Console.Clear();
        if (won)
        {
            Console.WriteLine("Congratulations! You've guessed the word!");
            Console.WriteLine($"The word was: {wordToGuess}");
            Console.WriteLine($"Your score for this round: {attempts * 10}");
            Console.WriteLine($"Total score: {totalScore}");
        }
        else
        {
            DisplayHangman(attempts);
            Console.WriteLine("\nGame over! You've run out of attempts.");
            Console.WriteLine($"The word was: {wordToGuess}");
            Console.WriteLine($"Total score: {totalScore}");
        }
    }

    static string ChooseDifficulty()
    {
        while (true)
        {
            Console.WriteLine("\nChoose a difficulty level:");
            Console.WriteLine("1. Easy");
            Console.WriteLine("2. Medium");
            Console.WriteLine("3. Hard");
            Console.Write("Enter your choice (1-3): ");
            string input = Console.ReadLine()?.Trim();

            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        return "Easy";
                    case 2:
                        return "Medium";
                    case 3:
                        return "Hard";
                    default:
                        Console.WriteLine("Invalid choice. Please select 1, 2, or 3.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a number (1-3).");
            }
        }
    }

    static string GetRandomWord(string difficulty)
    {
        List<string> words = wordCategories[difficulty];
        Random random = new Random();
        return words[random.Next(words.Count)];
    }

    static string GetHint(string word)
    {
        // For this example, we'll just return the first letter as a hint
        return word[0].ToString();
    }

    static void RevealLetter(string wordToGuess, char[] guessedWord, HashSet<char> guessedLetters)
    {
        for (int i = 0; i < wordToGuess.Length; i++)
        {
            if (guessedWord[i] == '_')
            {
                guessedWord[i] = wordToGuess[i];
                guessedLetters.Add(wordToGuess[i]);
                Console.WriteLine($"Hint used! The letter '{wordToGuess[i]}' has been revealed.");
                Console.WriteLine("Press any key to continue.");
                Console.ReadKey();
                break;
            }
        }
    }

    static void DisplayHangman(int attempts)
    {
        string[] hangmanStages = new string[]
        {
            @"
   +---+
   |   |
   O   |
  /|\  |
  / \  |
       |
========= ",
            @"
   +---+
   |   |
   O   |
  /|\  |
  /    |
       |
========= ",
            @"
   +---+
   |   |
   O   |
  /|\  |
       |
       |
========= ",
            @"
   +---+
   |   |
   O   |
  /|   |
       |
       |
========= ",
            @"
   +---+
   |   |
   O   |
   |   |
       |
       |
========= ",
            @"
   +---+
   |   |
   O   |
       |
       |
       |
========= ",
            @"
   +---+
   |   |
       |
       |
       |
       |
========= "
        };

        Console.WriteLine(hangmanStages[6 - attempts]);
    }
}
